#!/usr/bin/env python3
"""Run synthetic eligibility requests sequentially; terminate only owned workers."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import unicodedata

ROOT = Path('/Users/kash/Projects/parrot')
OUT = Path('/tmp/parrot-1046-native')
OUT.mkdir()
worker = ROOT / 'apps/desktop/src-tauri/target/release/parrot-quality-eval'
sidecar = ROOT / 'apps/desktop/src-tauri/target/release/cleanup-sidecar'
fixture = ROOT / 'apps/desktop/src-tauri/tests/fixtures/quality/cleanup-eligibility.json'
corpus = json.loads(fixture.read_text())
models = json.loads(Path('/tmp/parrot-1047-capacity-models.json').read_text())['cleanup']

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def content(text):
    return ''.join(c for c in unicodedata.normalize('NFKC', text).casefold()
                   if unicodedata.category(c)[0] in 'LNM')

rows = []
for repeat in (1, 2):
    for variant in models if repeat == 1 else list(reversed(models)):
        prefix = OUT / f'{variant["id"]}-{repeat}'
        request = prefix.with_suffix('.request.json')
        output = prefix.with_suffix('.jsonl')
        cases = [dict(id=case['id'], input=case['input'], stage='cleanup_pipeline', tones=['neutral'],
                      **{key: case[key] for key in ('cleanup_mode', 'cleanup_enabled') if key in case})
                 for case in corpus['cases']]
        request.write_text(json.dumps(dict(engine='cleanup', model=variant['model'], sidecar=str(sidecar), cases=cases), ensure_ascii=False, indent=2)+'\n')
        with prefix.with_suffix('.stdout.log').open('w') as stdout, prefix.with_suffix('.stderr.log').open('w') as stderr:
            process = subprocess.Popen([str(worker), str(request), str(output)], stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                status = process.wait(timeout=600)
            except BaseException:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
        assert status == 0, (variant['id'], repeat, status)
        records = [json.loads(line) for line in output.read_text().splitlines()]
        results = [row for row in records if row['kind'] == 'result']
        assert len(results) == len(corpus['cases'])
        assert sum(row['kind'] == 'loaded' for row in records) == 1
        for case, row in zip(corpus['cases'], results):
            assert row['id'] == case['id']
            assert 'error' not in row, row
            assert row['application_cleanup_eligible'] == case['expected_eligible'], row
            assert row['cleanup_skipped'] == (not case['expected_eligible']), row
            if row['cleanup_skipped']:
                assert row['text'] == case['input']
                assert row['segments'] == [] and 'complete' not in row
                assert row['model_output'] == '' and not row['fallback']
            else:
                assert row['segments'], row
                for segment in row['segments']:
                    assert segment['context_tokens'] == 2048
                    assert segment['prompt_tokens'] + segment['output_budget'] <= 2048
                if not row['complete']:
                    assert row['text'] == case['input'] and row['model_output'] == ''
            assert content(row['text']) == content(case['input']), row
            rows.append(dict(variant=variant['id'], repeat=repeat, **row))
        print(variant['id'], repeat, len(results), 'decisions verified', flush=True)

for variant in models:
    a = [row for row in rows if row['variant'] == variant['id'] and row['repeat'] == 1]
    b = [row for row in rows if row['variant'] == variant['id'] and row['repeat'] == 2]
    assert [(r['id'], r['text'], r.get('complete'), r['cleanup_skipped']) for r in a] == [(r['id'], r['text'], r.get('complete'), r['cleanup_skipped']) for r in b]
summary = dict(
    schema_version=1, source_revision=subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip(),
    hardware=subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'], text=True).strip(),
    ram_bytes=int(subprocess.check_output(['sysctl','-n','hw.memsize'], text=True)),
    worker_sha256=digest(worker), sidecar_sha256=digest(sidecar), fixture_sha256=digest(fixture),
    models=[dict(id=v['id'], sha256=digest(v['model'])) for v in models],
    cases=len(corpus['cases']), repeats=2, rows=len(rows),
    native_requests=sum(not r['cleanup_skipped'] for r in rows),
    bypasses=sum(r['cleanup_skipped'] for r in rows),
    incomplete=sum(r.get('complete') is False for r in rows),
    fallbacks=sum(r['fallback'] for r in rows),
    exact_text=sum(r['text'] == r['input'] for r in rows),
    normalized_content_retained=len(rows), repeat_text_and_status_identical=True,
    semantic_release_qualified=False, physical_device_qualified=False,
)
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
(OUT / 'rows.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(summary, indent=2), flush=True)
