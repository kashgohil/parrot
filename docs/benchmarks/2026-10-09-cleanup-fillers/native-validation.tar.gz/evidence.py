import collections
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/Users/kash/Projects/parrot')
OUT = ROOT / 'docs/benchmarks/2026-10-09-cleanup-fillers'
OUT.mkdir()
spec = importlib.util.spec_from_file_location('quality', ROOT / 'apps/desktop/scripts/quality-evaluation.py')
q = importlib.util.module_from_spec(spec)
spec.loader.exec_module(q)
files = {}
summary = dict(schema_version=1, rows=0, groups=[], comparisons={}, repeats={}, artifacts={},
               semantic_release_qualified=False, physical_device_qualified=False,
               note='Synthetic text and source-preservation checks; fallbacks are not successful model cleanup.')
loaded = {}
for corpus in ('faithfulness', 'fillers'):
    for phase in ('before', 'after'):
        name = f'{phase}-{corpus}'
        folder = Path('/tmp/parrot-1048-' + name)
        results = json.loads((folder / 'results.json').read_text())
        scores = json.loads((folder / 'scores.json').read_text())
        assert results['complete']
        assert scores['results_sha256'] == q.sha256(folder / 'results.json')
        assert not any(row.get('error') for row in results['rows'])
        assert len(results['rows']) == len(results['manifest']['cases']) * 3 * 3 * 2
        summary['rows'] += len(results['rows'])
        summary['artifacts'][name] = {key: results[key] for key in ('binary', 'sidecar', 'models', 'manifest_sha256', 'git_commit', 'git_diff_sha256', 'hardware')}
        oracle = {case['id']: case for case in results['manifest']['cases']}
        for row in results['rows']:
            assert not row['cleanup_skipped'] and row['segments']
            for segment in row['segments']:
                assert segment['prompt_tokens'] + segment['output_budget'] <= segment['context_tokens'] == 2048
            if row['complete'] is False:
                assert row['text'] == row['input'] and not row['model_output']
            if phase == 'after' and corpus == 'fillers':
                assert q.char_tokens(row['text']) == q.char_tokens(oracle[row['case']]['expected_deterministic']), row
        first = {row['key'].rsplit('/', 1)[0]: row for row in results['rows'] if row['repeat'] == 1}
        second = {row['key'].rsplit('/', 1)[0]: row for row in results['rows'] if row['repeat'] == 2}
        assert first.keys() == second.keys()
        signature = lambda row: (row['text'], row['complete'], row['finish_reason'], row['fallback'])
        assert all(signature(first[key]) == signature(second[key]) for key in first)
        summary['repeats'][name] = dict(pairs=len(first), identical_text_completion_and_fallback=True)
        scored = {row['key']: row for row in scores['rows']}
        for model in results['config']['cleanup']:
            rows = [row for row in results['rows'] if row['variant'] == model['id']]
            summary['groups'].append(dict(
                phase=phase, corpus=corpus, variant=model['id'], rows=len(rows),
                completed=sum(row['complete'] for row in rows),
                incomplete=sum(not row['complete'] for row in rows),
                fallbacks=sum(row['fallback'] for row in rows),
                exact_input=sum(row['text'] == row['input'] for row in rows),
                source_content_flags=sum(scored[row['key']]['properties']['introduced_regression'] for row in rows),
                reference_fact_flags=sum(bool(scored[row['key']]['properties']['reference_facts_failed']) for row in rows),
                normalized_oracle_mismatches=sum(q.char_tokens(row['text']) != q.char_tokens(oracle[row['case']]['expected_deterministic']) for row in rows) if corpus == 'fillers' else None,
                incomplete_cases=[{key: row[key] for key in ('case', 'tone', 'repeat', 'finish_reason')} for row in rows if not row['complete']],
            ))
        loaded[(phase, corpus)] = results
        for file in folder.iterdir():
            if file.is_file():
                files[name + '/' + file.name] = file.read_bytes()
    comparison = q.compare(Path('/tmp/parrot-1048-before-' + corpus), Path('/tmp/parrot-1048-after-' + corpus))
    assert comparison['regression_check_pass']
    summary['comparisons'][corpus] = comparison
    for key in ('manifest_sha256', 'models', 'sidecar'):
        assert loaded[('before', corpus)][key] == loaded[('after', corpus)][key]

assert summary['rows'] == 1584
assert all(row['reference_fact_flags'] == row['source_content_flags'] == 0 for row in summary['groups'] if row['phase'] == 'after' and row['corpus'] == 'fillers')
final = loaded[('after', 'fillers')]
cases = {case['id']: case for case in final['manifest']['cases']}
summary['focused_final_oracle_matches'] = 576
summary['focused_preserved_context_rows'] = sum(cases[row['case']]['expected_deterministic'] == row['input'] for row in final['rows'])
summary['focused_permitted_leading_pause_rows'] = 576 - summary['focused_preserved_context_rows']
summary['candidate_human_pending'] = sum(len(value['rows']) for (phase, _), value in loaded.items() if phase == 'after')
for label in ('cleanup-tests', 'focused-tests', 'default-tests', 'quality-tests', 'python-tests', 'worker-build', 'app-build', 'faithfulness-comparison', 'fillers-comparison', 'before-faithfulness', 'before-fillers', 'after-faithfulness', 'after-fillers'):
    files['logs/' + label + '.log'] = Path('/tmp/parrot-1048-' + label + '.log').read_bytes()
files['evidence.py'] = Path(__file__).read_bytes()
files['models.json'] = Path('/tmp/parrot-1048-models.json').read_bytes()
for name in ('cleanup-fillers', 'cleanup-faithfulness'):
    files['fixtures/' + name + '.json'] = (ROOT / 'apps/desktop/src-tauri/tests/fixtures/quality' / (name + '.json')).read_bytes()
files['summary.json'] = (json.dumps(summary, ensure_ascii=False, indent=2) + '\n').encode()
files['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(files.items())).encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
bundle = OUT / 'native-validation.tar.gz'
bundle.write_bytes(gzip.compress(buffer.getvalue(), mtime=0))
(OUT / 'summary.json').write_bytes(files['summary.json'])
(OUT / 'SHA256SUMS').write_text(''.join(q.sha256(file) + '  ' + file.name + '\n' for file in sorted(OUT.iterdir()) if file.is_file()))
with tarfile.open(bundle, 'r:gz') as archive:
    hashes = archive.extractfile('SHA256SUMS').read().decode().splitlines()
    for line in hashes:
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest
print('Verified', len(files), 'archive files;', summary['rows'], 'rows;', bundle.stat().st_size, 'archive bytes.')
print(json.dumps(summary['groups'], indent=2))
