# Local quality evaluation

Complete: True. Pending human review: 496.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| parakeet-v3 | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 3.1% | — | 108.1 |
| parakeet-v3 | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 75.7 |
| parakeet-v3 | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 10.5% | — | 102.4 |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 8 | — | — | 73.0 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 14 | — | — | 72.5 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 10 | — | — | 68.5 |
| qwen-0-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 10 | — | — | 70.0 |
| qwen-0-5b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 14 | — | — | 62.6 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 20 | — | — | 119.3 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 18 | — | — | 119.1 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 14 | — | — | 118.5 |
| qwen-1-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 114.1 |
| qwen-1-5b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 12 | — | — | 107.1 |
| qwen-3b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 2 | — | — | 229.0 |
| qwen-3b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 6 | — | — | 223.3 |
| qwen-3b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 4 | — | — | 223.6 |
| qwen-3b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 200.9 |
| qwen-3b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 8 | — | — | 201.0 |
| whisper-turbo-hindi-english | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 893.0 |
| whisper-turbo-hindi-english | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 818.2 |
| whisper-turbo-hindi-english | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 15.8% | — | 828.8 |
| whisper-turbo-hindi-english | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 948.3 |
| whisper-turbo-hindi-english | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 5.9% | 851.3 |
| whisper-turbo-hindi-english | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 960.7 |
| whisper-turbo-hindi-english | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 821.3 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 8. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
