# Local quality evaluation

Complete: True. Pending human review: 496.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| parakeet-v3 | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 3.1% | — | 101.5 |
| parakeet-v3 | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 72.3 |
| parakeet-v3 | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 10.5% | — | 97.4 |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 8 | — | — | 72.2 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 14 | — | — | 73.6 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 10 | — | — | 69.1 |
| qwen-0-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 10 | — | — | 69.9 |
| qwen-0-5b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 14 | — | — | 65.1 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 20 | — | — | 134.7 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 18 | — | — | 128.4 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 14 | — | — | 122.2 |
| qwen-1-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 120.3 |
| qwen-1-5b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 12 | — | — | 121.6 |
| qwen-3b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 2 | — | — | 279.3 |
| qwen-3b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 6 | — | — | 257.0 |
| qwen-3b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 4 | — | — | 259.3 |
| qwen-3b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 244.3 |
| qwen-3b | cleanup_pipeline / whisper-turbo-hindi-english | neutral | 30 | 0 | 12 | 0 | 8 | — | — | 243.3 |
| whisper-turbo-hindi-english | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 848.1 |
| whisper-turbo-hindi-english | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 782.3 |
| whisper-turbo-hindi-english | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 15.8% | — | 819.0 |
| whisper-turbo-hindi-english | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 846.0 |
| whisper-turbo-hindi-english | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 5.9% | 842.2 |
| whisper-turbo-hindi-english | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 877.1 |
| whisper-turbo-hindi-english | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 793.5 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 8. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
