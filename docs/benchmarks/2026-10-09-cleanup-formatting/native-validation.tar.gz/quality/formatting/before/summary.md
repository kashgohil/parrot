# Local quality evaluation

Complete: True. Pending human review: 144.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 6 | — | — | 72.2 |
| qwen-0-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 6 | — | — | 72.9 |
| qwen-0-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 6 | — | — | 73.0 |
| qwen-1-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 8 | — | — | 130.5 |
| qwen-1-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 8 | — | — | 130.4 |
| qwen-1-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 6 | — | — | 130.2 |
| qwen-3b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 0 | — | — | 260.1 |
| qwen-3b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 2 | — | — | 242.4 |
| qwen-3b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 0 | — | — | 238.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
