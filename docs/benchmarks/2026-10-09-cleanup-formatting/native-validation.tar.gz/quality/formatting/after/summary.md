# Local quality evaluation

Complete: True. Pending human review: 144.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 6 | — | — | 70.2 |
| qwen-0-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 6 | — | — | 69.6 |
| qwen-0-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 6 | — | — | 69.9 |
| qwen-1-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 8 | — | — | 123.0 |
| qwen-1-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 8 | — | — | 122.9 |
| qwen-1-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 6 | — | — | 121.0 |
| qwen-3b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 0 | — | — | 231.0 |
| qwen-3b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 2 | — | — | 214.9 |
| qwen-3b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 0 | — | — | 210.4 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
