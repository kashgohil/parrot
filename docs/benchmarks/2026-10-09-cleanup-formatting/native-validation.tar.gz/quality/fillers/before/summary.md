# Local quality evaluation

Complete: True. Pending human review: 576.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 64 | 0 | 0 | 0 | 38 | — | — | 44.5 |
| qwen-0-5b | cleanup_isolated | formal | 64 | 0 | 0 | 0 | 42 | — | — | 45.0 |
| qwen-0-5b | cleanup_isolated | neutral | 64 | 0 | 0 | 0 | 40 | — | — | 44.8 |
| qwen-1-5b | cleanup_isolated | casual | 64 | 0 | 0 | 0 | 48 | — | — | 86.4 |
| qwen-1-5b | cleanup_isolated | formal | 64 | 0 | 0 | 0 | 48 | — | — | 86.9 |
| qwen-1-5b | cleanup_isolated | neutral | 64 | 0 | 0 | 0 | 48 | — | — | 86.2 |
| qwen-3b | cleanup_isolated | casual | 64 | 0 | 0 | 0 | 36 | — | — | 165.0 |
| qwen-3b | cleanup_isolated | formal | 64 | 0 | 0 | 0 | 44 | — | — | 157.3 |
| qwen-3b | cleanup_isolated | neutral | 64 | 0 | 0 | 0 | 34 | — | — | 164.3 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
