# Local quality evaluation

Complete: True. Pending human review: 216.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 4 | — | — | 76.3 |
| qwen-0-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 10 | — | — | 74.2 |
| qwen-0-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 10 | — | — | 68.7 |
| qwen-1-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 14 | — | — | 122.2 |
| qwen-1-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 8 | — | — | 122.2 |
| qwen-1-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 6 | — | — | 125.0 |
| qwen-3b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 4 | — | — | 237.6 |
| qwen-3b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 6 | — | — | 222.1 |
| qwen-3b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 6 | — | — | 216.6 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
