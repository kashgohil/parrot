import subprocess
from pathlib import Path
root=Path('/Users/kash/Projects/parrot')
worker=root/'apps/desktop/src-tauri/target/release/parrot-quality-eval'
sidecar=root/'apps/desktop/src-tauri/target/release/cleanup-sidecar'
for name,manifest,config in [('formatting','cleanup-formatting','cleanup-models'),('seed','manifest','models'),('faithfulness','cleanup-faithfulness','cleanup-models'),('fillers','cleanup-fillers','cleanup-models')]:
    print('Running',name,flush=True)
    with open('/tmp/parrot-1082-'+name+'.log','w') as log:
        subprocess.run(['python3',str(root/'apps/desktop/scripts/quality-evaluation.py'),'run','--config','/tmp/parrot-1051-'+config+'.json','--manifest',str(root/'apps/desktop/src-tauri/tests/fixtures/quality'/(manifest+'.json')),'--binary',str(worker),'--sidecar',str(sidecar),'--output','/tmp/parrot-1082-'+name,'--repeats','2'],stdout=log,stderr=subprocess.STDOUT,check=True)
    baseline='/tmp/parrot-1051-'+('seed-final' if name=='seed' else name)
    with open('/tmp/parrot-1082-'+name+'-comparison.log','w') as log:
        subprocess.run(['python3',str(root/'apps/desktop/scripts/quality-evaluation.py'),'compare','--baseline',baseline,'--candidate','/tmp/parrot-1082-'+name],stdout=log,stderr=subprocess.STDOUT,check=True)
print('All four corpus comparisons passed.',flush=True)
