import subprocess
from pathlib import Path
root=Path('/Users/kash/Projects/parrot')
for phase,worker,sidecar in [('before',Path('/tmp/parrot-1082-baseline/parrot-quality-eval'),Path('/tmp/parrot-1082-baseline/cleanup-sidecar')),('after',root/'apps/desktop/src-tauri/target/release/parrot-quality-eval',root/'apps/desktop/src-tauri/target/release/cleanup-sidecar')]:
 print('Resource comparison',phase,flush=True)
 with open('/tmp/parrot-1082-resources-'+phase+'.log','w') as log:
  subprocess.run(['python3',str(root/'apps/desktop/scripts/cleanup-tier-memory.py'),'--config','/tmp/parrot-1051-cleanup-models.json','--manifest',str(root/'apps/desktop/src-tauri/tests/fixtures/quality/manifest.json'),'--binary',str(worker),'--sidecar',str(sidecar),'--output','/tmp/parrot-1082-resources-'+phase,'--repeats','2'],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Finished',phase,flush=True)
