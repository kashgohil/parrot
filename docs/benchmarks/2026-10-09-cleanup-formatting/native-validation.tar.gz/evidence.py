import argparse, collections, gzip, hashlib, importlib.util, io, json, statistics, subprocess, tarfile
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--repo',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
a=p.parse_args(); root=a.repo.resolve()
s=importlib.util.spec_from_file_location('quality',root/'apps/desktop/scripts/quality-evaluation.py');q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
files={};summary=dict(schema_version=1,semantic_release_qualified=False,physical_device_qualified=False,quality_rows_per_phase=0,groups=[],formatting=[],comparisons={},provenance={},repeat_differences={},resources={})
def aggregate(rows,scores):
 native=[r for r in rows if r.get('segments')]
 return dict(rows=len(rows),native_requests=len(native),fallbacks=sum(r.get('fallback',False) for r in rows),formatting_applied=sum(r.get('formatting_applied',False) for r in rows),incomplete=sum(r.get('complete') is False for r in rows),bypassed=sum(r.get('cleanup_skipped',False) for r in rows),source_content_flags=sum(scores[r['key']]['properties'].get('introduced_regression',False) for r in rows),reference_fact_flags=sum(bool(scores[r['key']]['properties']['reference_facts_failed']) for r in rows),median_native_ms=statistics.median(r['latency_ms'] for r in native) if native else None)
for corpus in ['seed','faithfulness','fillers','formatting']:
 paths=[Path('/tmp/parrot-1051-'+('seed-final' if corpus=='seed' else corpus)),Path('/tmp/parrot-1082-'+corpus)]
 data=[json.loads((f/'results.json').read_text()) for f in paths]
 assert all(d['complete'] and d['repeats']==2 for d in data)
 check=q.compare(*paths);assert check['regression_check_pass'],check;summary['comparisons'][corpus]=check
 summary['quality_rows_per_phase']+=len(data[1]['rows'])
 indexed=[{r['key']:r for r in d['rows']} for d in data];assert indexed[0].keys()==indexed[1].keys()
 for key,r in indexed[1].items():
  before=indexed[0][key]
  for field in ['input','system_prompt','user_message','model_output','candidate','complete','finish_reason','fallback','cleanup_skipped']:
   assert before.get(field)==r.get(field),(corpus,key,field)
  if r['stage']=='asr':assert r['text']==before['text']
  elif r.get('cleanup_skipped') or r.get('complete') is False:assert r['text']==before['text']==r['input']
  else:assert r['unformatted_text']==before['text']
  for segment in r.get('segments',[]):assert segment['prompt_tokens']+segment['output_budget']<=segment['context_tokens']==2048
 for phase,d,folder in zip(['before','after'],data,paths):
  scores=json.loads((folder/'scores.json').read_text());assert scores['results_sha256']==q.sha256(folder/'results.json')
  scored={r['key']:r for r in scores['rows']}; assert not any(r.get('error') for r in d['rows'])
  summary['provenance'][corpus+'/'+phase]={key:d[key] for key in ['binary','sidecar','models','git_commit','git_diff_sha256','manifest_sha256','hardware']}
  first={r['key'].rsplit('/',1)[0]:r for r in d['rows'] if r['repeat']==1};second={r['key'].rsplit('/',1)[0]:r for r in d['rows'] if r['repeat']==2}
  assert first.keys()==second.keys()
  sig=lambda r:(r['text'],r.get('model_output'),r.get('complete'),r.get('fallback'),r.get('formatting_applied'))
  different=[k for k in first if sig(first[k])!=sig(second[k])];assert not different,different
  summary['repeat_differences'][corpus+'/'+phase]=different
  groups=collections.defaultdict(list)
  for r in d['rows']:
   if r['stage']!='asr':groups[(r['variant'],r['stage'])].append(r)
  for (model,stage),rows in sorted(groups.items()):summary['groups'].append(dict(corpus=corpus,phase=phase,variant=model,stage=stage,**aggregate(rows,scored)))
  cases={c['id']:c for c in d['manifest']['cases']}
  if corpus=='fillers':
   for r in d['rows']:assert q.char_tokens(r['text'])==q.char_tokens(cases[r['case']]['expected_deterministic'])
  if corpus=='formatting':
   for model in [m['id'] for m in d['config']['cleanup']]:
    rows=[r for r in d['rows'] if r['variant']==model];checks=[dict(key=r['key'],case=r['case'],tone=r['tone'],repeat=r['repeat'],languages=cases[r['case']]['languages'],output=r['text'],**q.formatting_check(cases[r['case']],r['text'])) for r in rows]
    summary['formatting'].append(dict(phase=phase,variant=model,rows=len(rows),passes=sum(c['passed'] for c in checks),checks=checks))
  for f in folder.iterdir():
   if f.is_file():files['quality/'+corpus+'/'+phase+'/'+f.name]=f.read_bytes()
for phase in ['before','after']:
 folder=Path('/tmp/parrot-1082-resources-'+phase);report=json.loads((folder/'report.json').read_text());assert report['complete'] and len(report['runs'])==6
 for run in report['runs']:
  stem=run['variant']+'-'+str(run['repeat']); samples=json.loads((folder/(stem+'.samples.json')).read_text())
  complete=[s for s in samples if s['processes'] and all('phys_footprint' in x and 'resident_size' in x for x in s['processes'])]
  assert len(complete)==run['complete_samples']
  assert max(sum(x['phys_footprint'] for x in s['processes']) for s in complete)==run['peak_footprint_bytes']
  assert max(sum(x['resident_size'] for x in s['processes']) for s in complete)==run['peak_rss_bytes']
  assert q.sha256(folder/(stem+'.request.json'))==run['request_sha256'];assert q.sha256(folder/(stem+'.jsonl'))==run['output_sha256']
 summary['resources'][phase]=report
 for f in folder.iterdir():
  if f.is_file():files['resources/'+phase+'/'+f.name]=f.read_bytes()
summary['excluded_diagnostics']=['Prompt-only exploratory run; the production prompt was restored unchanged.', 'Initial formatter run before source-based question and dependent-clause abstention refinements.']
for suffix in ['formatting-exploratory','formatting-exploratory-formatter']:
 folder=Path('/tmp/parrot-1082-'+suffix)
 for f in folder.iterdir():
  if f.is_file():files['excluded/'+suffix+'/'+f.name]=f.read_bytes()
for label in ['formatting','formatting-exploratory','formatting-exploratory-formatter','seed','faithfulness','fillers','worker-build','sidecar-build','rust-tests','default-tests','python-tests','resources-before','resources-after']:
 f=Path('/tmp/parrot-1082-'+label+'.log');files['logs/'+f.name]=f.read_bytes()
for label in ['models','cleanup-models']:
 f=Path('/tmp/parrot-1051-'+label+'.json');files['config/'+label+'.json']=f.read_bytes()
for name in ['quality-evaluation.py','test_quality_evaluation.py','cleanup-tier-memory.py','test_cleanup_tier_memory.py','memory-benchmark.py']:
 files['source/scripts/'+name]=(root/'apps/desktop/scripts'/name).read_bytes()
for name in ['cleanup.rs','cleanup_formatting.rs','cleanup_fillers.rs','cleanup_eligibility.rs','cleanup_engine.rs','cleanup_protocol.rs','quality_eval.rs']:
 files['source/native/'+name]=(root/'apps/desktop/src-tauri/src'/name).read_bytes()
for name in ['cleanup.rs','cleanup_fillers.rs','cleanup_eligibility.rs','cleanup_engine.rs','cleanup_protocol.rs','quality_eval.rs']:
 files['source/baseline/'+name]=subprocess.check_output(['git','-C',str(root),'show','3d74ae5:apps/desktop/src-tauri/src/'+name])
files['source/excluded-initial-formatter.rs']=subprocess.check_output(['git','-C',str(root),'show','75d47a2:apps/desktop/src-tauri/src/cleanup_formatting.rs'])
files['source/native/engine.rs']=(root/'apps/desktop/src-tauri/cleanup-sidecar/src/engine.rs').read_bytes()
for name in ['manifest','cleanup-faithfulness','cleanup-fillers','cleanup-formatting']:
 files['fixtures/'+name+'.json']=(root/'apps/desktop/src-tauri/tests/fixtures/quality'/(name+'.json')).read_bytes()
for name in ['cleanup-formatting.md','benchmarks/2026-10-09-cleanup-formatting.md']:
 files['docs/'+name]=(root/'docs'/name).read_bytes()
files['evidence.py']=Path(__file__).read_bytes();files['run-quality.py']=Path('/tmp/parrot-1082-run.py').read_bytes();files['run-resources.py']=Path('/tmp/parrot-1082-resources.py').read_bytes();files['report.py']=Path('/tmp/parrot-1082-report.py').read_bytes()
files['summary.json']=(json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode()
a.output.mkdir(parents=True,exist_ok=False)
files['SHA256SUMS']=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items())).encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
(a.output/'native-validation.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0))
(a.output/'summary.json').write_bytes(files['summary.json'])
(a.output/'SHA256SUMS').write_text(''.join(q.sha256(f)+'  '+f.name+'\n' for f in sorted(a.output.iterdir())))
with tarfile.open(a.output/'native-validation.tar.gz','r:gz') as tar:
 for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
print('Verified',len(files),'files;',summary['quality_rows_per_phase'],'quality rows per phase')
print(json.dumps({k:summary[k] for k in ['groups']},indent=2))
