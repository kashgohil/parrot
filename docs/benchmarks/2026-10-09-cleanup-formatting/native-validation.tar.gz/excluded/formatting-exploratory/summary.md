# Local quality evaluation

Complete: True. Pending human review: 144.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 2 | — | — | 72.3 |
| qwen-0-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 6 | — | — | 63.7 |
| qwen-0-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 6 | — | — | 69.7 |
| qwen-1-5b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 6 | — | — | 118.0 |
| qwen-1-5b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 6 | — | — | 121.4 |
| qwen-1-5b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 4 | — | — | 118.2 |
| qwen-3b | cleanup_isolated | casual | 16 | 0 | 0 | 0 | 0 | — | — | 235.6 |
| qwen-3b | cleanup_isolated | formal | 16 | 0 | 0 | 0 | 0 | — | — | 222.3 |
| qwen-3b | cleanup_isolated | neutral | 16 | 0 | 0 | 0 | 0 | — | — | 221.3 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
