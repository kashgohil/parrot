# Local quality evaluation

Complete: True. Pending human review: 60.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact | asr | auto / en | 16 | 0 | 8 | 0 | 0 | 9.5% | — | 314.5 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 37.5% | — | 293.7 |
| whisper-compact | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 52.6% | — | 330.4 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 16.1% | 339.3 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 47.1% | 288.6 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 291.4 |
| whisper-compact | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 244.4 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 893.2 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 810.0 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 15.8% | — | 859.4 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 889.2 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 5.9% | 938.4 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 1036.0 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 954.5 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
