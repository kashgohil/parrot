# Local quality evaluation

Complete: True. Pending human review: 64.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact-full-context | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 51.6% | 506.4 |
| whisper-compact-full-context | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 344.3 |
| whisper-compact-full-context | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 51.6% | 373.5 |
| whisper-compact-full-context | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 267.3 |
| whisper-compact-full-context-segmented | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 51.6% | 504.5 |
| whisper-compact-full-context-segmented | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 340.8 |
| whisper-compact-full-context-segmented | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 51.6% | 370.7 |
| whisper-compact-full-context-segmented | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 265.1 |
| whisper-compact-production | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 334.8 |
| whisper-compact-production | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 255.5 |
| whisper-compact-production | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 198.8 |
| whisper-compact-production | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 148.0 |
| whisper-compact-segmented | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 334.4 |
| whisper-compact-segmented | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 265.1 |
| whisper-compact-segmented | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 200.5 |
| whisper-compact-segmented | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 149.4 |
| whisper-turbo-full-context | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 1395.7 |
| whisper-turbo-full-context | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 1390.8 |
| whisper-turbo-full-context | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 805.5 |
| whisper-turbo-full-context | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 41.2% | 771.6 |
| whisper-turbo-full-context-segmented | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 1468.2 |
| whisper-turbo-full-context-segmented | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 1329.8 |
| whisper-turbo-full-context-segmented | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 799.0 |
| whisper-turbo-full-context-segmented | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 41.2% | 747.8 |
| whisper-turbo-production | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 894.7 |
| whisper-turbo-production | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 820.1 |
| whisper-turbo-production | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 260.4 |
| whisper-turbo-production | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 242.4 |
| whisper-turbo-segmented | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 947.6 |
| whisper-turbo-segmented | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 882.7 |
| whisper-turbo-segmented | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 275.0 |
| whisper-turbo-segmented | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 257.6 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
