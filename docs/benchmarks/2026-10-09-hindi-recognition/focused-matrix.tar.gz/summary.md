# Local quality evaluation

Complete: True. Pending human review: 400.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact-full | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 348.0 |
| whisper-compact-full | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 37.7% | 494.5 |
| whisper-compact-full | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 60.1% | 413.9 |
| whisper-compact-full | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 210.8 |
| whisper-compact-full | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 37.7% | 357.6 |
| whisper-compact-full | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 55.1% | 347.0 |
| whisper-compact-production | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 229.0 |
| whisper-compact-production | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 336.7 |
| whisper-compact-production | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 65.4% | 268.6 |
| whisper-compact-production | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 98.3 |
| whisper-compact-production | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 200.9 |
| whisper-compact-production | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 54.7% | 186.6 |
| whisper-compact-segmented | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 320.6 |
| whisper-compact-segmented | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 339.6 |
| whisper-compact-segmented | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 65.4% | 401.7 |
| whisper-compact-segmented | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 131.7 |
| whisper-compact-segmented | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 200.9 |
| whisper-compact-segmented | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 54.7% | 240.4 |
| whisper-compact-style | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 315.6 |
| whisper-compact-style | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 18.0% | 437.7 |
| whisper-compact-style | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 55.6% | 479.5 |
| whisper-compact-style | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 136.8 |
| whisper-compact-style | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 18.0% | 292.7 |
| whisper-compact-style | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 57.2% | 288.2 |
| whisper-compact-vocabulary | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 325.0 |
| whisper-compact-vocabulary | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 23.0% | 471.5 |
| whisper-compact-vocabulary | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 51.4% | 390.8 |
| whisper-compact-vocabulary | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 137.3 |
| whisper-compact-vocabulary | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 23.0% | 306.0 |
| whisper-compact-vocabulary | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 40.3% | 248.5 |
| whisper-turbo-full | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 1443.2 |
| whisper-turbo-full | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 1427.3 |
| whisper-turbo-full | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 34.2% | 1403.5 |
| whisper-turbo-full | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 752.2 |
| whisper-turbo-full | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 783.5 |
| whisper-turbo-full | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 22.2% | 803.9 |
| whisper-turbo-production | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 827.6 |
| whisper-turbo-production | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 915.8 |
| whisper-turbo-production | asr | auto / hi+en | 14 | 0 | 12 | 0 | 0 | — | 53.5% | 844.7 |
| whisper-turbo-production | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 196.9 |
| whisper-turbo-production | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 268.4 |
| whisper-turbo-production | asr | hi / hi+en | 14 | 0 | 12 | 0 | 0 | — | 51.0% | 246.7 |
| whisper-turbo-segmented | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 888.5 |
| whisper-turbo-segmented | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 957.7 |
| whisper-turbo-segmented | asr | auto / hi+en | 14 | 0 | 12 | 0 | 0 | — | 53.5% | 976.2 |
| whisper-turbo-segmented | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 204.7 |
| whisper-turbo-segmented | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 282.0 |
| whisper-turbo-segmented | asr | hi / hi+en | 14 | 0 | 12 | 0 | 0 | — | 51.0% | 271.1 |
| whisper-turbo-style | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 906.9 |
| whisper-turbo-style | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 963.7 |
| whisper-turbo-style | asr | auto / hi+en | 14 | 0 | 12 | 0 | 0 | — | 5.3% | 989.7 |
| whisper-turbo-style | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 223.8 |
| whisper-turbo-style | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 289.9 |
| whisper-turbo-style | asr | hi / hi+en | 14 | 0 | 12 | 0 | 0 | — | 4.9% | 273.4 |
| whisper-turbo-vocabulary | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 871.1 |
| whisper-turbo-vocabulary | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 960.3 |
| whisper-turbo-vocabulary | asr | auto / hi+en | 14 | 0 | 10 | 0 | 0 | — | 116.9% | 980.9 |
| whisper-turbo-vocabulary | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 204.1 |
| whisper-turbo-vocabulary | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 283.4 |
| whisper-turbo-vocabulary | asr | hi / hi+en | 14 | 0 | 10 | 0 | 0 | — | 100.4% | 288.3 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
