#!/usr/bin/env python3
"""Repeat owned local quality workers and sample their macOS physical ledger."""
import argparse, hashlib, importlib.util, json, os, platform, signal, statistics, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);a=p.parse_args()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
memory=module('memory',a.repo/'apps/desktop/scripts/memory-benchmark.py').MacMemory()
quality=module('quality',a.repo/'apps/desktop/scripts/quality-evaluation.py')
binary=a.repo/'apps/desktop/src-tauri/target/release/parrot-quality-eval';a.out.mkdir(exist_ok=False)
report={'scope':'Headless ASR worker only; includes model load. Excludes UI, cleanup, microphone, other app processes and energy. Not target-device qualification.', 'interval_ms':50,'hardware':{**platform.uname()._asdict(),'ram_bytes':subprocess.check_output(['sysctl','-n','hw.memsize'],text=True).strip(),'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip()},'binary':quality.fingerprint(binary),'runs':[]}
for repeat in [1,2]:
 # Reverse condition order on the second repeat to reduce a one-direction cache bias.
 conditions=['default','hint','hint-words','full-context']
 if repeat==2:conditions.reverse()
 for model in ['whisper-turbo','whisper-compact']:
  for condition in conditions:
   config=json.loads((a.baseline/f'{model}-1.request.json').read_text())
   for case in config['cases']:
    case['prompt_style']='hindi-english' if condition.startswith('hint') else 'default'
    case['initial_prompt']='Vocabulary hints: Kubernetes.' if condition=='hint-words' else None
    if model=='whisper-compact' and condition.startswith('hint'):
     case['initial_prompt']='आज meeting में project status पर discussion होगा।'+('\nVocabulary hints: Kubernetes.' if condition=='hint-words' else '')
     case['prompt_style']='default'  # Diagnostic raw-prompt experiment; app mode refuses compact.
    case['whisper_decode_profile']='full-context' if condition=='full-context' else 'production'
   name=f'{model}-{condition}-{repeat}';request=a.out/f'{name}.request.json';output=a.out/f'{name}.jsonl'
   quality.write_json(request,config)
   started=time.monotonic();samples=[]
   with (a.out/f'{name}.stderr.log').open('w') as log:
    proc=subprocess.Popen([str(binary),str(request),str(output)],stdout=log,stderr=log,start_new_session=True)
    try:
     while proc.poll() is None:
      if time.monotonic()-started>180:raise TimeoutError(name)
      usage=memory.usage(proc.pid)
      samples.append({'elapsed_ms':(time.monotonic()-started)*1000,**usage})
      time.sleep(.05)
    finally:
     if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   quality.write_json(a.out/f'{name}.samples.json',samples)
   rows=[json.loads(line) for line in output.read_text().splitlines()]
   results=[r for r in rows if r['kind']=='result'];assert proc.returncode==0 and len(results)==10 and not any(r.get('error') for r in results)
   good=[s for s in samples if 'phys_footprint' in s];assert good
   row={'model':model,'condition':condition,'diagnostic_only':model=='whisper-compact' and condition.startswith('hint'),'repeat':repeat,'sample_count':len(samples),'sample_errors':sum('error' in s for s in samples),
        'sampled_peak_footprint_bytes':max(s['phys_footprint'] for s in good),'lifetime_peak_footprint_bytes':max(s['lifetime_max_phys_footprint'] for s in good),
        'sampled_peak_rss_bytes':max(s['resident_size'] for s in good),'load_ms':rows[0]['load_ms'],
        'median_inference_ms':statistics.median(r['latency_ms'] for r in results),'elapsed_ms':(time.monotonic()-started)*1000,
        'request_sha256':quality.sha256(request),'output_sha256':quality.sha256(output),'model_file':quality.fingerprint(config['model'])}
   report['runs'].append(row);quality.write_json(a.out/'report.json',report);print(name,row['lifetime_peak_footprint_bytes'],round(row['median_inference_ms']),flush=True)
