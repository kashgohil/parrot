# Local quality evaluation

Complete: True. Pending human review: 40.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact-words | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 236.7 |
| whisper-compact-words | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 19.7% | 341.1 |
| whisper-compact-words | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 51.4% | 332.2 |
| whisper-turbo-words | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 825.0 |
| whisper-turbo-words | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 59.0% | 972.0 |
| whisper-turbo-words | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 21.8% | 875.1 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
