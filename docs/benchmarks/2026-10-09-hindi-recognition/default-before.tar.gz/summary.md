# Local quality evaluation

Complete: True. Pending human review: 120.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 304.3 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 342.5 |
| whisper-compact | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 331.6 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 502.8 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 373.3 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 412.2 |
| whisper-compact | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 340.5 |
| whisper-compact | asr | en / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 171.9 |
| whisper-compact | asr | es / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 155.6 |
| whisper-compact | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 181.4 |
| whisper-compact | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 304.2 |
| whisper-compact | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 226.1 |
| whisper-compact | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 229.7 |
| whisper-compact | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 156.7 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 1055.2 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 944.9 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 1105.8 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 1028.5 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 968.5 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 1207.1 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 1055.0 |
| whisper-turbo | asr | en / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 303.6 |
| whisper-turbo | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 222.9 |
| whisper-turbo | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 299.8 |
| whisper-turbo | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 297.8 |
| whisper-turbo | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 288.6 |
| whisper-turbo | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 465.7 |
| whisper-turbo | asr | zh / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 265.0 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
