# Local quality evaluation

Complete: True. Pending human review: 40.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 229.2 |
| whisper-compact | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 329.0 |
| whisper-compact | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 65.4% | 265.0 |
| whisper-turbo | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 816.2 |
| whisper-turbo | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 904.0 |
| whisper-turbo | asr | auto / hi+en | 14 | 0 | 12 | 0 | 0 | — | 53.5% | 884.6 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
