# Local quality evaluation

Complete: True. Pending human review: 120.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-compact | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 242.7 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 225.9 |
| whisper-compact | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 244.1 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 316.7 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 244.6 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 275.3 |
| whisper-compact | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 230.8 |
| whisper-compact | asr | en / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 118.4 |
| whisper-compact | asr | es / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 101.6 |
| whisper-compact | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 120.9 |
| whisper-compact | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 194.3 |
| whisper-compact | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 143.7 |
| whisper-compact | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 151.7 |
| whisper-compact | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 106.7 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 851.4 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 792.1 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 835.8 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 860.0 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 811.6 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 894.7 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 808.2 |
| whisper-turbo | asr | en / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 258.2 |
| whisper-turbo | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 193.6 |
| whisper-turbo | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 231.1 |
| whisper-turbo | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 257.6 |
| whisper-turbo | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 244.4 |
| whisper-turbo | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 291.4 |
| whisper-turbo | asr | zh / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 204.9 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
