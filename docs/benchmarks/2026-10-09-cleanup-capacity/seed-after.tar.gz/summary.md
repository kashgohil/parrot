# Local quality evaluation

Complete: True. Pending human review: 288.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 6 | — | — | 75.8 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 14 | — | — | 75.6 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 6 | — | — | 73.0 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 16 | — | — | 123.7 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 16 | — | — | 124.0 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 14 | — | — | 122.3 |
| qwen-3b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 4 | — | — | 236.1 |
| qwen-3b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 6 | — | — | 233.3 |
| qwen-3b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 4 | — | — | 227.5 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
