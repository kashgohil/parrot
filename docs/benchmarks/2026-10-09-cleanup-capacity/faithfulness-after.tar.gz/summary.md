# Local quality evaluation

Complete: True. Pending human review: 216.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 6 | — | — | 75.1 |
| qwen-0-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 10 | — | — | 72.5 |
| qwen-0-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 8 | — | — | 70.7 |
| qwen-1-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 12 | — | — | 130.3 |
| qwen-1-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 12 | — | — | 125.9 |
| qwen-1-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 8 | — | — | 139.2 |
| qwen-3b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 4 | — | — | 261.9 |
| qwen-3b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 6 | — | — | 229.8 |
| qwen-3b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 4 | — | — | 237.1 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
