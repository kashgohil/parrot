#!/usr/bin/env python3
"""Sample owned headless cleanup workers and descendants on macOS."""
import argparse, importlib.util, json, os, platform, signal, subprocess, time
from pathlib import Path

p = argparse.ArgumentParser()
for key in ('repo', 'config', 'manifest', 'out', 'before-binary', 'before-sidecar'):
    p.add_argument('--' + key, type=Path, required=True)
a = p.parse_args()
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
bench = module('memory', a.repo / 'apps/desktop/scripts/memory-benchmark.py')
quality = module('quality', a.repo / 'apps/desktop/scripts/quality-evaluation.py')
memory = bench.MacMemory()
manifest = quality.read_manifest(a.manifest)
long = next(c for c in manifest['cases'] if c['id'] == 'hi-numbered-long')['cleanup_input']
models = json.loads(a.config.read_text())['cleanup']
conditions = {'before': (a.before_binary, a.before_sidecar),
              'after': (a.repo / 'apps/desktop/src-tauri/target/release/parrot-quality-eval',
                        a.repo / 'apps/desktop/src-tauri/target/release/cleanup-sidecar')}
a.out.mkdir(exist_ok=False)
report = dict(scope='Headless cleanup worker plus its owned descendants, including load. Excludes UI, microphone, ASR, other installed app processes and energy; not target-device qualification.',
    interval_ms=50, hardware={**platform.uname()._asdict(),
        'ram_bytes': subprocess.check_output(['sysctl','-n','hw.memsize'], text=True).strip(),
        'chip': subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'], text=True).strip()},
    manifest_sha256=quality.sha256(a.manifest), models={m['id']:quality.fingerprint(m['model']) for m in models},
    binaries={k:{'worker':quality.fingerprint(v[0]),'sidecar':quality.fingerprint(v[1])} for k,v in conditions.items()}, runs=[])
for repeat in (1, 2):
    for model in (models if repeat == 1 else list(reversed(models))):
        for condition in (['before','after'] if repeat == 1 else ['after','before']):
            binary, sidecar = conditions[condition]
            name = f"{model['id']}-{condition}-{repeat}"
            request = a.out / (name + '.request.json'); output = a.out / (name + '.jsonl')
            quality.write_json(request, dict(engine='cleanup', model=model['model'], sidecar=str(sidecar), cases=[
                dict(id='warm-short', input='Priya did not approve invoice 25 on Friday.', stage='cleanup_isolated', tones=['neutral']),
                dict(id='hi-numbered-long', input=long, stage='cleanup_isolated', tones=['neutral'])]))
            samples, peaks, started = [], {}, time.monotonic()
            with (a.out / (name + '.stderr.log')).open('wb') as log:
                proc = subprocess.Popen([str(binary), str(request), str(output)], stdout=log, stderr=log, start_new_session=True)
                try:
                    while proc.poll() is None:
                        if time.monotonic() - started > 600: raise TimeoutError(name)
                        table = bench.process_table()
                        pids = bench.select_processes(table, {proc.pid}, None)
                        usages = []
                        for pid in sorted(pids):
                            usage = dict(pid=pid, role='worker' if pid == proc.pid else 'owned_child', **memory.usage(pid))
                            usages.append(usage)
                            if 'phys_footprint' in usage:
                                key = str(pid) + '/' + str(usage['proc_start_abstime'])
                                if key not in peaks: peaks[key] = dict(pid=pid, role=usage['role'], command=table[pid]['command'], lifetime_peak_bytes=0)
                                peaks[key]['lifetime_peak_bytes'] = max(peaks[key]['lifetime_peak_bytes'], usage['lifetime_max_phys_footprint'])
                        samples.append(dict(elapsed_ms=(time.monotonic()-started)*1000, processes=usages,
                            summed_footprint_bytes=sum(u.get('phys_footprint',0) for u in usages),
                            summed_rss_bytes=sum(u.get('resident_size',0) for u in usages)))
                        time.sleep(.05)
                finally:
                    if proc.poll() is None: os.killpg(proc.pid, signal.SIGKILL); proc.wait()
            quality.write_json(a.out / (name + '.samples.json'), samples)
            rows = [json.loads(line) for line in output.read_text().splitlines()]
            results = [row for row in rows if row['kind'] == 'result']
            assert proc.returncode == 0 and len(results) == 2 and any(s['processes'] for s in samples)
            report['runs'].append(dict(model=model['id'], condition=condition, repeat=repeat,
                sampled_peak_summed_footprint_bytes=max(s['summed_footprint_bytes'] for s in samples),
                sampled_peak_summed_rss_bytes=max(s['summed_rss_bytes'] for s in samples), process_lifetime_peaks=peaks,
                sample_count=len(samples), sample_errors=sum('error' in u for s in samples for u in s['processes']),
                elapsed_ms=(time.monotonic()-started)*1000, load_ms=rows[0]['load_ms'],
                results=[{k:row.get(k) for k in ('id','error','latency_ms','complete','finish_reason','fallback')} for row in results],
                request_sha256=quality.sha256(request), output_sha256=quality.sha256(output)))
            quality.write_json(a.out / 'report.json', report)
            print(name, report['runs'][-1]['sampled_peak_summed_footprint_bytes'], flush=True)
