# Local quality evaluation

Complete: True. Pending human review: 54.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | neutral | 18 | 0 | 0 | 0 | 16 | — | — | 4651.5 |
| qwen-1-5b | cleanup_isolated | neutral | 18 | 0 | 0 | 0 | 16 | — | — | 5409.0 |
| qwen-3b | cleanup_isolated | neutral | 18 | 0 | 0 | 0 | 8 | — | — | 19545.5 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
