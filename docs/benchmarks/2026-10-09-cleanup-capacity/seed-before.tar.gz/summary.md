# Local quality evaluation

Complete: True. Pending human review: 288.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 6 | — | — | 76.4 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 14 | — | — | 77.0 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 6 | — | — | 75.3 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 16 | — | — | 129.6 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 16 | — | — | 130.6 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 14 | — | — | 128.1 |
| qwen-3b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 4 | — | — | 254.6 |
| qwen-3b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 6 | — | — | 239.3 |
| qwen-3b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 4 | — | — | 242.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
