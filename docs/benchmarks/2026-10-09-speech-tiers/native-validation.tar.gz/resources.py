#!/usr/bin/env python3
"""Measure only newly launched ASR workers; use existing ledger helpers."""
import argparse, hashlib, importlib.util, json, os, platform, signal, subprocess, time, statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path);p.add_argument('--config',required=True,type=Path);p.add_argument('--seed',required=True,type=Path);p.add_argument('--focused',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
def module(name,filename):
 spec=importlib.util.spec_from_file_location(name,a.repo/'apps/desktop/scripts'/filename);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
q=module('quality','quality-evaluation.py');b=module('memory','memory-benchmark.py');tiers=module('tiers','cleanup-tier-memory.py');memory=b.MacMemory()
binary=a.repo/'apps/desktop/src-tauri/target/release/parrot-quality-eval';models=json.loads(a.config.read_text())['speech'];a.output.mkdir(exist_ok=False)
report=dict(complete=False,scope='Fresh owned headless ASR worker, including loading. Excludes GUI, cleanup, capture, installed app, other applications and energy.',sample_interval_ms=50,file_cache_controlled=False,hardware={**platform.uname()._asdict(),'ram_bytes':b.command('sysctl','-n','hw.memsize'),'chip':b.command('sysctl','-n','machdep.cpu.brand_string')},binary=q.fingerprint(binary),git_commit=q.command_output(['git','rev-parse','HEAD']),git_diff_sha256=hashlib.sha256(q.command_output(['git','diff','HEAD']).encode()).hexdigest(),models={m['id']:q.fingerprint(m['model']) for m in models},runs=[])
q.write_json(a.output/'report.json',report)
for repeat in [1,2]:
 for model in models if repeat==1 else list(reversed(models)):
  variant=model['id'];seed=json.loads((a.seed/f'{variant}-1.request.json').read_text());focused=json.loads((a.focused/f'{variant}-1.request.json').read_text())
  auto=[c for c in seed['cases'] if c['language']=='auto'];short=next(c for c in auto if c['id']=='en-basic/auto')
  cases=[{**short,'id':'first-short'},{**short,'id':'warm-short'}]+[{**c,'id':'seed/'+c['id']} for c in auto]+[{**c,'id':'focused/'+c['id']} for c in focused['cases'] if c['language']=='auto']
  request={**seed,'cases':cases};name=f'{variant}-{repeat}';req=a.output/f'{name}.request.json';out=a.output/f'{name}.jsonl';q.write_json(req,request);samples=[];started=time.monotonic()
  with (a.output/f'{name}.stderr.log').open('wb') as log:
   proc=subprocess.Popen([str(binary),str(req),str(out)],stdout=log,stderr=log,start_new_session=True)
   try:
    while proc.poll() is None:
     if time.monotonic()-started>600:raise TimeoutError(name)
     table=b.process_table();pids=b.select_processes(table,{proc.pid},None)
     samples.append(dict(elapsed_ms=(time.monotonic()-started)*1000,processes=[dict(pid=pid,role='worker' if pid==proc.pid else 'owned_child',command=table[pid]['command'],**memory.usage(pid)) for pid in sorted(pids)]));time.sleep(.05)
   finally:
    if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    q.write_json(a.output/f'{name}.samples.json',samples)
  rows=[json.loads(line) for line in out.read_text().splitlines()];loaded=[r for r in rows if r['kind']=='loaded'];results=[r for r in rows if r['kind']=='result']
  assert proc.returncode==0 and len(loaded)==1 and [r['id'] for r in results]==[c['id'] for c in cases] and not any(r.get('error') for r in results),name
  byid={r['id']:r for r in results};assert byid['first-short']['text']==byid['warm-short']['text']
  valid=[s for s in samples if s['processes'] and all('phys_footprint' in c and 'resident_size' in c for c in s['processes'])]
  row=dict(variant=variant,repeat=repeat,**tiers.summarize_samples(samples),lifetime_peak_worker_footprint_bytes=max(c['lifetime_max_phys_footprint'] for s in valid for c in s['processes'] if c['role']=='worker'),load_ms=loaded[0]['load_ms'],first_ms=byid['first-short']['latency_ms'],warm_ms=byid['warm-short']['latency_ms'],long_ms=byid['seed/long-120s/auto']['latency_ms'],median_short_ms=statistics.median(r['latency_ms'] for r in results if r['id'] not in ['seed/long-120s/auto','seed/silence/auto','seed/short-input/auto']),request_sha256=q.sha256(req),output_sha256=q.sha256(out),results=results)
  report['runs'].append(row);q.write_json(a.output/'report.json',report);print(name,json.dumps({k:v for k,v in row.items() if k!='results'}),flush=True)
report['complete']=True;q.write_json(a.output/'report.json',report)
