import collections,hashlib,json,statistics
from pathlib import Path
repo=Path('/Users/kash/Projects/parrot')
def read(p):return json.loads(Path(p).read_text())
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
runs={name:read(f'/tmp/parrot-1045-{name}/results.json') for name in ['seed','focused']};scores={name:read(f'/tmp/parrot-1045-{name}/scores.json') for name in runs};memory=read('/tmp/parrot-1045-resources/report.json');upstream=read('/tmp/parrot-1045-upstream.json');config=read('/tmp/parrot-1045-models.json')
assert memory['complete'] and len(memory['runs'])==6
for name,r in runs.items():
 assert r['complete'] and scores[name]['complete'] and not r['skipped'] and not any(x.get('error') for x in r['rows'])
 pairs=collections.defaultdict(list)
 for x in r['rows']:pairs[(x['variant'],x['case'],x['language'])].append(x['text'])
 assert all(len(v)==2 and v[0]==v[1] for v in pairs.values())
 assert all(not x['human_review'].get('decision') for x in scores[name]['rows'])
 assert r['binary']==memory['binary']
for m in config['speech']:
 p=Path(m['model']);name=p.name.replace('parrot-1045-','').replace('parrot-1058-','');artifact=upstream['artifacts'][name]
 assert sha(p)==artifact['lfs']['sha256'] and p.stat().st_size==artifact['size']
 for r in runs.values():assert r['models'][m['id']]==memory['models'][m['id']]
for x in memory['runs']:
 name=f"{x['variant']}-{x['repeat']}";folder=Path('/tmp/parrot-1045-resources');assert sha(folder/(name+'.request.json'))==x['request_sha256'] and sha(folder/(name+'.jsonl'))==x['output_sha256']
 samples=read(folder/(name+'.samples.json'));good=[s for s in samples if s['processes'] and all('phys_footprint' in p and 'resident_size' in p for p in s['processes'])]
 assert len(samples)==x['sample_count'] and len(good)==x['complete_samples'] and len(samples)-len(good)==x['incomplete_samples']
 assert max(sum(p['phys_footprint'] for p in s['processes']) for s in good)==x['peak_footprint_bytes']
 assert max(sum(p['resident_size'] for p in s['processes']) for s in good)==x['peak_rss_bytes']
 seed={r['id']:r for r in read(f"/tmp/parrot-1045-seed/results.json")['rows'] if r['variant']==x['variant'] and r['repeat']==x['repeat']}
 focused={r['id']:r for r in read(f"/tmp/parrot-1045-focused/results.json")['rows'] if r['variant']==x['variant'] and r['repeat']==x['repeat']}
 for row in x['results']:
  source=seed if row['id'].startswith('seed/') else focused
  key=row['id'].split('/',1)[1] if '/' in row['id'] else 'en-basic/auto'
  if key=='en-basic/auto':source=seed
  assert row['text']==source[key]['text'],(name,row['id'])
a=read('/tmp/parrot-1074-regression-final/results.json');b=runs['seed'];key=lambda x:(x['variant'],x['case'],x['language'],x['repeat']);old={key(x):x for x in a['rows']};new={key(x):x for x in b['rows'] if x['variant']!='whisper-base'}
assert old.keys()==new.keys() and all(old[k]['text']==new[k]['text'] for k in old);assert a['manifest_sha256']==b['manifest_sha256'];assert all(a['models'][m]==b['models'][m] for m in a['models'])
summary=dict(schema_version=1,semantic_release_qualified=False,decision='Retain optional compact small Q5_1 with recognition tradeoffs; do not add base Q5_1 to Settings after Hindi script/amount and long-input screening failures.',priority_languages=['en','hi','hi+en'],review_pending=300,quality_rows=300,quality_repeat_pairs=150,existing_default_transcripts_unchanged=120,resource_rows=sum(len(x['results']) for x in memory['runs']),upstream=upstream,quality={name:dict(rows=len(r['rows']),groups=scores[name]['groups'],binary=r['binary'],models=r['models'],manifest_sha256=r['manifest_sha256'],audio=r['audio']) for name,r in runs.items()},resources=memory)
Path('/tmp/parrot-1045-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Verified 300 scored rows, 150 repeated pairs, 120 unchanged existing transcripts, 162 matching resource rows, all model hashes and six resource ledgers.')
