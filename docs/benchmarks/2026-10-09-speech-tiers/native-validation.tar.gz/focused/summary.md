# Local quality evaluation

Complete: True. Pending human review: 120.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-base | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 94.5 |
| whisper-base | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 98.4% | 125.6 |
| whisper-base | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 79.8% | 114.5 |
| whisper-base | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 52.1 |
| whisper-base | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 98.4% | 70.8 |
| whisper-base | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 83.5% | 79.4 |
| whisper-compact | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 291.4 |
| whisper-compact | asr | auto / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 347.4 |
| whisper-compact | asr | auto / hi+en | 14 | 0 | 14 | 0 | 0 | — | 65.4% | 356.7 |
| whisper-compact | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 126.1 |
| whisper-compact | asr | hi / hi | 4 | 0 | 4 | 0 | 0 | — | 21.3% | 214.0 |
| whisper-compact | asr | hi / hi+en | 14 | 0 | 14 | 0 | 0 | — | 54.7% | 203.9 |
| whisper-turbo | asr | auto / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 1191.4 |
| whisper-turbo | asr | auto / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 1396.7 |
| whisper-turbo | asr | auto / hi+en | 14 | 0 | 12 | 0 | 0 | — | 53.5% | 1424.2 |
| whisper-turbo | asr | en / en | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 274.4 |
| whisper-turbo | asr | hi / hi | 4 | 0 | 2 | 0 | 0 | — | 4.9% | 373.4 |
| whisper-turbo | asr | hi / hi+en | 14 | 0 | 12 | 0 | 0 | — | 51.0% | 368.6 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
