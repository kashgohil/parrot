#!/usr/bin/env python3
"""Verify extracted ISSUE-1045 evidence without model weights or private data."""
import argparse,collections,hashlib,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);root=p.parse_args().root
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text())
entries=(root/'SHA256SUMS').read_text().splitlines()
for line in entries:
 digest,name=line.split('  ',1);assert sha(root/name)==digest,name
quality={name:read(root/name/'results.json') for name in ['seed','focused']};summary=read(root/'summary.json');resources=read(root/'resources/report.json')
assert resources['complete'] and len(resources['runs'])==6
for name,r in quality.items():
 assert r['complete'] and not r['skipped'] and not any(x.get('error') for x in r['rows'])
 scores=read(root/name/'scores.json');assert scores['complete'] and not scores['semantic_release_qualified']
 assert scores['results_sha256']==sha(root/name/'results.json');assert all(not x['human_review'].get('decision') for x in scores['rows'])
 assert r['binary']==resources['binary']
 for m in r['models']:
  assert r['models'][m]==resources['models'][m]
 pairs=collections.defaultdict(list)
 for x in r['rows']:pairs[(x['variant'],x['case'],x['language'])].append(x['text'])
 assert all(len(v)==2 and len(set(v))==1 for v in pairs.values())
 for m in r['models']:
  for repeat in [1,2]:
   req=read(root/name/f'{m}-{repeat}.request.json');rows=[json.loads(x) for x in (root/name/f'{m}-{repeat}.jsonl').read_text().splitlines()];native=[x for x in rows if x['kind']=='result']
   assert len([x for x in rows if x['kind']=='loaded'])==1 and [x['id'] for x in native]==[x['id'] for x in req['cases']]
   scored={x['id']:x for x in r['rows'] if x['variant']==m and x['repeat']==repeat}
   assert all(x['text']==scored[x['id']]['text'] for x in native)
for x in resources['runs']:
 name=f"{x['variant']}-{x['repeat']}";samples=read(root/'resources'/f'{name}.samples.json');good=[s for s in samples if s['processes'] and all('phys_footprint' in c and 'resident_size' in c for c in s['processes'])]
 assert len(samples)==x['sample_count'] and len(good)==x['complete_samples'] and len(samples)-len(good)==x['incomplete_samples']
 assert max(sum(c['phys_footprint'] for c in s['processes']) for s in good)==x['peak_footprint_bytes'];assert max(sum(c['resident_size'] for c in s['processes']) for s in good)==x['peak_rss_bytes']
 assert sha(root/'resources'/f'{name}.request.json')==x['request_sha256'] and sha(root/'resources'/f'{name}.jsonl')==x['output_sha256']
 rows=[json.loads(line) for line in (root/'resources'/f'{name}.jsonl').read_text().splitlines()];native=[r for r in rows if r['kind']=='result'];req=read(root/'resources'/f'{name}.request.json');assert [r['id'] for r in native]==[c['id'] for c in req['cases']] and native==x['results']
 for r in native:
  corpus,ident=r['id'].split('/',1) if '/' in r['id'] else ('seed','en-basic/auto')
  rows=[z for z in quality[corpus]['rows'] if z['variant']==x['variant'] and z['repeat']==x['repeat'] and z['id']==ident];assert len(rows)==1 and r['text']==rows[0]['text']
previous=read(root/'previous-default/results.json');key=lambda x:(x['variant'],x['case'],x['language'],x['repeat']);old={key(x):x for x in previous['rows']};new={key(x):x for x in quality['seed']['rows'] if x['variant']!='whisper-base'}
assert old.keys()==new.keys() and len(old)==120 and all(old[k]['text']==new[k]['text'] for k in old)
assert previous['manifest_sha256']==quality['seed']['manifest_sha256'] and all(previous['models'][m]==quality['seed']['models'][m] for m in previous['models'])
for model in resources['models'].values():
 f=model['files'][0];expected=[a for a in summary['upstream']['artifacts'].values() if a['lfs']['sha256']==f['sha256']];assert len(expected)==1 and f['bytes']==expected[0]['size']
assert sum(len(r['rows']) for r in quality.values())==300 and summary['quality_rows']==300 and summary['review_pending']==300
assert summary['resource_rows']==sum(len(x['results']) for x in resources['runs'])==162 and not summary['semantic_release_qualified']
print(f'Verified {len(entries)} hashed files, 300 scored rows, 120 unchanged previous transcripts, 162 resource rows and six complete ledger runs.')
