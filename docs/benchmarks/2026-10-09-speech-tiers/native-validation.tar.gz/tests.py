import json,os,subprocess
from pathlib import Path
repo=Path('/Users/kash/Projects/parrot');cwd=repo/'apps/desktop/src-tauri'
def run(cmd,name,env=None,workdir=cwd):
 with Path('/tmp/parrot-1045-'+name+'.log').open('wb') as f:r=subprocess.run(cmd,cwd=workdir,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True);assert r.returncode==0,name
run(['cargo','test','--locked','-p','parrot','--lib','--features','quality-eval'],'rust-tests')
config=json.loads(Path('/tmp/parrot-1045-models.json').read_text())
for m in config['speech']:
 env={**os.environ,'PARROT_TEST_WHISPER_MODEL':m['model']}
 run(['cargo','test','--locked','-p','parrot','--lib','--features','quality-eval','whisper_loaded_model_capabilities','--','--ignored','--nocapture'],'native-'+m['id'],env)
 if m['id']=='whisper-compact':
  run(['cargo','test','--locked','-p','parrot','--lib','--features','quality-eval','whisper_multilingual_inference','--','--ignored','--nocapture'],'compact-languages',env)
run(['bun','run','build'],'frontend',workdir=repo/'apps/desktop')
