# Local quality evaluation

Complete: True. Pending human review: 180.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| whisper-base | asr | auto / en | 16 | 0 | 8 | 0 | 0 | 3.1% | — | 107.2 |
| whisper-base | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 96.9 |
| whisper-base | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 15.8% | — | 103.1 |
| whisper-base | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 96.8% | 107.3 |
| whisper-base | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 94.5 |
| whisper-base | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 122.3 |
| whisper-base | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 98.1 |
| whisper-base | asr | en / en | 16 | 0 | 8 | 0 | 0 | 3.1% | — | 63.5 |
| whisper-base | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 63.4 |
| whisper-base | asr | fr / fr | 4 | 0 | 2 | 0 | 0 | 15.8% | — | 63.7 |
| whisper-base | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 96.8% | 64.4 |
| whisper-base | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 86.0 |
| whisper-base | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 75.6 |
| whisper-base | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 56.0 |
| whisper-compact | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 246.2 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 228.6 |
| whisper-compact | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 253.6 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 322.9 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 248.0 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 277.9 |
| whisper-compact | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 233.9 |
| whisper-compact | asr | en / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 119.4 |
| whisper-compact | asr | es / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 103.0 |
| whisper-compact | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 121.9 |
| whisper-compact | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 193.5 |
| whisper-compact | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 143.7 |
| whisper-compact | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 159.1 |
| whisper-compact | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 108.9 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 875.8 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 801.8 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 850.1 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 864.4 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 815.5 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 917.5 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 814.7 |
| whisper-turbo | asr | en / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 250.4 |
| whisper-turbo | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 193.1 |
| whisper-turbo | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 240.4 |
| whisper-turbo | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 256.4 |
| whisper-turbo | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 241.7 |
| whisper-turbo | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 300.4 |
| whisper-turbo | asr | zh / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 203.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
