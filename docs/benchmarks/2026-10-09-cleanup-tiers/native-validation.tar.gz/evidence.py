import argparse, collections, gzip, hashlib, importlib.util, io, json, statistics, subprocess, tarfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--input-prefix',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args(); root=a.repo.resolve(); prefix=str(a.input_prefix)
s=importlib.util.spec_from_file_location('quality',root/'apps/desktop/scripts/quality-evaluation.py'); q=importlib.util.module_from_spec(s);s.loader.exec_module(q)
files={}; result=dict(schema_version=1,semantic_release_qualified=False,physical_device_qualified=False,scored_rows=0,groups=[],language_groups=[],repeats={},provenance={},formatting=[],resources=None)
def count(rows,scored):
 native=[r for r in rows if r.get('segments')]
 return dict(rows=len(rows),native_requests=len(native),bypasses=sum(r.get('cleanup_skipped',False) for r in rows),errors=sum(bool(r.get('error')) for r in rows),incomplete=sum(r.get('complete') is False for r in rows),fallbacks=sum(r.get('fallback',False) for r in rows),exact_input=sum(r.get('text')==r.get('input') for r in rows),changed=sum(r.get('text','').strip()!=r.get('input','').strip() for r in rows),source_content_flags=sum(scored[r['key']]['properties'].get('introduced_regression',False) for r in rows),reference_fact_flags=sum(bool(scored[r['key']]['properties']['reference_facts_failed']) for r in rows),candidate_content_flags=sum(scored[r['key']].get('candidate_properties',{}).get('introduced_regression',False) for r in rows),median_native_ms=statistics.median(r['latency_ms'] for r in native) if native else None)
for name,suffix in [('seed','seed-final'),('faithfulness','faithfulness'),('fillers','fillers'),('formatting','formatting')]:
 folder=Path(prefix+'-'+suffix); data=json.loads((folder/'results.json').read_text());scores=json.loads((folder/'scores.json').read_text())
 assert data['complete'] and scores['results_sha256']==q.sha256(folder/'results.json')
 assert not any(row.get('error') for row in data['rows'])
 assert data['repeats']==2 and len(data['config']['cleanup'])==3
 result['scored_rows']+=len(data['rows'])
 result['provenance'][name]={k:data[k] for k in ('binary','sidecar','models','manifest_sha256','git_commit','git_diff_sha256','hardware')}
 for row in data['rows']:
  for part in row.get('segments',[]): assert part['prompt_tokens']+part['output_budget']<=part['context_tokens']==2048
  if row.get('complete') is False: assert row['text']==row['input'] and not row['model_output']
  if row.get('cleanup_skipped'): assert not row['segments'] and row['text']==row['input'] and 'system_prompt' not in row and 'complete' not in row
 first={r['key'].rsplit('/',1)[0]:r for r in data['rows'] if r['repeat']==1}; second={r['key'].rsplit('/',1)[0]:r for r in data['rows'] if r['repeat']==2}
 assert first.keys()==second.keys()
 signature=lambda r:(r['text'],r.get('complete'),r.get('finish_reason'),r.get('fallback'),r.get('cleanup_skipped'),r.get('model_output'),r.get('candidate'))
 different=[key for key in first if signature(first[key])!=signature(second[key])]
 result['repeats'][name]=dict(pairs=len(first),different=different)
 cases={c['id']:c for c in data['manifest']['cases']};scored={r['key']:r for r in scores['rows']}
 groups=collections.defaultdict(list); languages=collections.defaultdict(list);prompts=collections.defaultdict(list)
 for row in data['rows']:
  if row['stage']=='asr': continue
  groups[(row['variant'],row['stage'])].append(row)
  languages[(row['variant'],row['stage'],'+'.join(cases[row['case']]['languages']))].append(row)
  key=row['key'].split('/',1)[1]
  prompts[key].append((row['input'],row.get('system_prompt'),row.get('cleanup_skipped')))
  if name=='fillers': assert q.char_tokens(row['text'])==q.char_tokens(cases[row['case']]['expected_deterministic'])
 assert all(len(v)==3 and v[0]==v[1]==v[2] for v in prompts.values()),'Mismatched model inputs/prompts'
 for (model,stage), rows in sorted(groups.items()):result['groups'].append(dict(corpus=name,variant=model,stage=stage,**count(rows,scored)))
 for (model,stage,language),rows in sorted(languages.items()):result['language_groups'].append(dict(corpus=name,variant=model,stage=stage,language=language,**count(rows,scored)))
 if name=='formatting':
  for model in (m['id'] for m in data['config']['cleanup']):
   for tone in ['neutral','casual','formal']:
    rows=[r for r in data['rows'] if r['variant']==model and r['tone']==tone];checks=[]
    for r in rows:
     criteria=cases[r['case']]['format_check'];text=r['text'].strip();terminal=any(text.endswith(c) for c in criteria['terminal']);case=not criteria.get('initial_uppercase') or text[:1].isupper()
     checks.append(dict(case=r['case'],repeat=r['repeat'],terminal=terminal,initial_case=case,pass_check=terminal and case,output=text))
    result['formatting'].append(dict(variant=model,tone=tone,rows=len(rows),passes=sum(c['pass_check'] for c in checks),checks=checks))
 for f in folder.iterdir():
  if f.is_file():files[name+'/'+f.name]=f.read_bytes()
folder=Path(prefix+'-resources'); resource=json.loads((folder/'report.json').read_text());assert resource['complete'] and len(resource['runs'])==6
result['resources']=resource
result['excluded_diagnostics']=['Incomplete first seed runner attempt: missing system_prompt on a native bypass.', 'Exploratory resource measurements overlapped frontend compilation; only the subsequent quiet six-run resource comparison is used.']
for run in resource['runs']:
 name=f"{run['variant']}-{run['repeat']}"
 samples=json.loads((folder/(name+'.samples.json')).read_text());complete=[s for s in samples if s['processes'] and all('phys_footprint' in p and 'resident_size' in p for p in s['processes'])]
 assert len(complete)==run['complete_samples']
 assert max(sum(p['phys_footprint'] for p in s['processes']) for s in complete)==run['peak_footprint_bytes']
 assert q.sha256(folder/(name+'.request.json'))==run['request_sha256']
 assert q.sha256(folder/(name+'.jsonl'))==run['output_sha256']
for f in folder.iterdir():
 if f.is_file():files['resources/'+f.name]=f.read_bytes()
folder=Path(prefix+'-resources-exploratory')
for f in folder.iterdir():
 if f.is_file():files['diagnostic-exploratory-resources/'+f.name]=f.read_bytes()
files['logs/resources-exploratory.log']=Path(prefix+'-resources-exploratory.log').read_bytes()
# The first runner attempt is explicitly incomplete and excluded from metrics.
folder=Path(prefix+'-seed');assert not json.loads((folder/'results.json').read_text())['complete']
for f in folder.iterdir():
 if f.is_file():files['diagnostic-incomplete-seed/'+f.name]=f.read_bytes()
for label in ['seed','seed-final','faithfulness','fillers','formatting','resources','python-tests','worker-build','sidecar-build','frontend-build']:
 f=Path(prefix+'-'+label+'.log'); files['logs/'+f.name]=f.read_bytes()
for label in ['models','cleanup-models']:
 f=Path(prefix+'-'+label+'.json');files[f.name]=f.read_bytes()
for name in ['quality-evaluation.py','cleanup-tier-memory.py','test_cleanup_tier_memory.py','test_quality_evaluation.py']:
 files['source/'+name]=(root/'apps/desktop/scripts'/name).read_bytes()
for name in ['manifest','cleanup-fillers','cleanup-faithfulness','cleanup-formatting']:
 files['fixtures/'+name+'.json']=(root/'apps/desktop/src-tauri/tests/fixtures/quality'/(name+'.json')).read_bytes()
files['source/settings.tsx']=(root/'apps/desktop/src/routes/settings.tsx').read_bytes()
for name in ['cleanup.rs','cleanup_fillers.rs','cleanup_eligibility.rs','cleanup_engine.rs','cleanup_protocol.rs','quality_eval.rs','local_setup.rs']:
 files['source/native/'+name]=subprocess.check_output(['git','-C',str(root),'show','f5b3696:apps/desktop/src-tauri/src/'+name])
files['source/native/engine.rs']=subprocess.check_output(['git','-C',str(root),'show','f5b3696:apps/desktop/src-tauri/cleanup-sidecar/src/engine.rs'])
files['docs/cleanup-tiers.md']=(root/'docs/benchmarks/2026-10-09-cleanup-tiers.md').read_bytes()
files['docs/comparison.md']=(root/'docs/cleanup-tier-comparison.md').read_bytes()
files['evidence.py']=Path(__file__).read_bytes()
files['summary.json']=(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode()
a.output.mkdir(exist_ok=False,parents=True)
files['SHA256SUMS']=''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in sorted(files.items())).encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
archive=a.output/'native-validation.tar.gz';archive.write_bytes(gzip.compress(buf.getvalue(),mtime=0))
(a.output/'summary.json').write_bytes(files['summary.json'])
(a.output/'SHA256SUMS').write_text(''.join(q.sha256(f)+'  '+f.name+'\n' for f in sorted(a.output.iterdir())))
with tarfile.open(archive,'r:gz') as tar:
 for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
print('Verified',len(files),'files;',result['scored_rows'],'scored rows;',archive.stat().st_size,'bytes')
print(json.dumps({k:result[k] for k in ['groups','repeats']},indent=2))
