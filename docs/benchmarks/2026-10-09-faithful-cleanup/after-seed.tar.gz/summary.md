# Local quality evaluation

Complete: True. Pending human review: 498.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| parakeet-v3 | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 3.1% | — | 124.6 |
| parakeet-v3 | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 79.0 |
| parakeet-v3 | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 10.5% | — | 109.3 |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 6 | — | — | 74.1 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 14 | — | — | 74.0 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 6 | — | — | 70.7 |
| qwen-0-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 71.0 |
| qwen-0-5b | cleanup_pipeline / whisper-compact | neutral | 30 | 0 | 14 | 0 | 10 | — | — | 66.4 |
| qwen-0-5b | cleanup_pipeline / whisper-turbo | neutral | 30 | 0 | 10 | 0 | 8 | — | — | 70.2 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 16 | — | — | 123.9 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 16 | — | — | 127.3 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 14 | — | — | 121.1 |
| qwen-1-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 8 | — | — | 132.1 |
| qwen-1-5b | cleanup_pipeline / whisper-compact | neutral | 30 | 0 | 14 | 0 | 8 | — | — | 118.5 |
| qwen-1-5b | cleanup_pipeline / whisper-turbo | neutral | 30 | 0 | 10 | 0 | 10 | — | — | 119.3 |
| whisper-compact | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 239.2 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 226.4 |
| whisper-compact | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 242.6 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 318.9 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 255.5 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 283.9 |
| whisper-compact | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 234.8 |
| whisper-compact | asr | en / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 117.5 |
| whisper-compact | asr | es / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 105.4 |
| whisper-compact | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 120.3 |
| whisper-compact | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 202.0 |
| whisper-compact | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 153.0 |
| whisper-compact | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 175.2 |
| whisper-compact | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 112.2 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 900.2 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 818.0 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 878.1 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 885.9 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 843.6 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 932.7 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 844.7 |
| whisper-turbo | asr | en / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 267.6 |
| whisper-turbo | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 196.5 |
| whisper-turbo | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 246.7 |
| whisper-turbo | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 277.8 |
| whisper-turbo | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 259.6 |
| whisper-turbo | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 305.8 |
| whisper-turbo | asr | zh / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 217.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 8. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
