# Local quality evaluation

Complete: True. Pending human review: 498.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| parakeet-v3 | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 3.1% | — | 146.2 |
| parakeet-v3 | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 81.1 |
| parakeet-v3 | asr | auto / fr | 4 | 0 | 2 | 0 | 0 | 10.5% | — | 109.3 |
| qwen-0-5b | cleanup_isolated | casual | 32 | 0 | 2 | 2 | 4 | — | — | 97.6 |
| qwen-0-5b | cleanup_isolated | formal | 32 | 0 | 2 | 2 | 4 | — | — | 95.6 |
| qwen-0-5b | cleanup_isolated | neutral | 32 | 0 | 2 | 2 | 4 | — | — | 94.9 |
| qwen-0-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 2 | — | — | 73.3 |
| qwen-0-5b | cleanup_pipeline / whisper-compact | neutral | 30 | 0 | 12 | 2 | 4 | — | — | 69.7 |
| qwen-0-5b | cleanup_pipeline / whisper-turbo | neutral | 30 | 0 | 12 | 2 | 4 | — | — | 74.2 |
| qwen-1-5b | cleanup_isolated | casual | 32 | 0 | 2 | 2 | 6 | — | — | 193.9 |
| qwen-1-5b | cleanup_isolated | formal | 32 | 0 | 2 | 2 | 6 | — | — | 193.0 |
| qwen-1-5b | cleanup_isolated | neutral | 32 | 0 | 2 | 2 | 6 | — | — | 192.4 |
| qwen-1-5b | cleanup_pipeline / parakeet-v3 | neutral | 22 | 0 | 8 | 0 | 2 | — | — | 127.5 |
| qwen-1-5b | cleanup_pipeline / whisper-compact | neutral | 30 | 0 | 14 | 0 | 6 | — | — | 123.4 |
| qwen-1-5b | cleanup_pipeline / whisper-turbo | neutral | 30 | 0 | 10 | 0 | 6 | — | — | 129.7 |
| whisper-compact | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 248.3 |
| whisper-compact | asr | auto / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 251.6 |
| whisper-compact | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 246.9 |
| whisper-compact | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 381.0 |
| whisper-compact | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 58.8% | 253.8 |
| whisper-compact | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 280.9 |
| whisper-compact | asr | auto / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 238.2 |
| whisper-compact | asr | en / en | 16 | 0 | 6 | 0 | 0 | 4.2% | — | 130.4 |
| whisper-compact | asr | es / es | 2 | 0 | 2 | 0 | 0 | 25.0% | — | 130.1 |
| whisper-compact | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 122.8 |
| whisper-compact | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 19.4% | 230.5 |
| whisper-compact | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 44.1% | 149.4 |
| whisper-compact | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 155.1 |
| whisper-compact | asr | zh / zh | 2 | 0 | 2 | 0 | 0 | — | 8.3% | 111.3 |
| whisper-turbo | asr | auto / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 897.9 |
| whisper-turbo | asr | auto / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 782.8 |
| whisper-turbo | asr | auto / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 821.7 |
| whisper-turbo | asr | auto / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 852.6 |
| whisper-turbo | asr | auto / hi+en | 2 | 0 | 2 | 0 | 0 | — | 61.8% | 803.4 |
| whisper-turbo | asr | auto / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 886.7 |
| whisper-turbo | asr | auto / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 797.2 |
| whisper-turbo | asr | en / en | 16 | 0 | 6 | 0 | 0 | 2.8% | — | 246.6 |
| whisper-turbo | asr | es / es | 2 | 0 | 0 | 0 | 0 | 0.0% | — | 188.6 |
| whisper-turbo | asr | fr / fr | 4 | 0 | 0 | 0 | 0 | 5.3% | — | 228.7 |
| whisper-turbo | asr | hi / hi | 2 | 0 | 2 | 0 | 0 | — | 9.7% | 257.3 |
| whisper-turbo | asr | hi / hi+en | 2 | 0 | 2 | 0 | 0 | — | 64.7% | 240.1 |
| whisper-turbo | asr | ja / ja | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 293.0 |
| whisper-turbo | asr | zh / zh | 2 | 0 | 0 | 0 | 0 | — | 0.0% | 201.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 8. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
