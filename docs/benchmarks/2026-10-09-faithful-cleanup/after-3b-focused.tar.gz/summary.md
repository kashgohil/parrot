# Local quality evaluation

Complete: True. Pending human review: 72.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-3b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 4 | — | — | 244.8 |
| qwen-3b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 6 | — | — | 229.5 |
| qwen-3b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 4 | — | — | 228.8 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
