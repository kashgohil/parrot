# Local quality evaluation

Complete: True. Pending human review: 96.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-3b | cleanup_isolated | casual | 32 | 0 | 0 | 0 | 4 | — | — | 225.2 |
| qwen-3b | cleanup_isolated | formal | 32 | 0 | 0 | 0 | 6 | — | — | 220.6 |
| qwen-3b | cleanup_isolated | neutral | 32 | 0 | 0 | 0 | 4 | — | — | 219.0 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
