# Local quality evaluation

Complete: True. Pending human review: 144.

| Variant | Stage / upstream | Tone / language | Cases | Errors | Fact flags | New cleanup flags | Fallbacks | WER | CER | Median ms |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| qwen-0-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 6 | — | — | 97.8 |
| qwen-0-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 10 | — | — | 96.4 |
| qwen-0-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 8 | — | — | 95.2 |
| qwen-1-5b | cleanup_isolated | casual | 24 | 0 | 0 | 2 | 12 | — | — | 223.5 |
| qwen-1-5b | cleanup_isolated | formal | 24 | 0 | 0 | 2 | 12 | — | — | 216.1 |
| qwen-1-5b | cleanup_isolated | neutral | 24 | 0 | 0 | 2 | 8 | — | — | 237.0 |

WER and CER aggregates include only cases declaring that primary metric; empty references use absolute insertion counts.
Fact/script flags screen for regressions. Review source and output before judging meaning or cleanup usefulness.
Skipped unsupported combinations: 0. These are not passing evaluations.
This synthetic seed does not qualify any model or language for release.
